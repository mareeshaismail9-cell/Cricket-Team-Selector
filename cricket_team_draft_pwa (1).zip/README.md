# Cricket Team Draft

- Animated six-team wheel and First-to-Sixth pick order.
- First-pick probabilities are hidden under Settings and require password `1122`.
- Drag any probability slider; the other five teams automatically share the remainder equally, keeping the total at 100%.
- Settings lock after the first spin. Picks 2–6 are equally random among remaining teams.
- Reset entire draft restores equal chances and hides settings again.
- PWA support: serve over HTTPS to install on a phone and enable offline caching after first visit.

## Publish
Upload all files in this folder to a static HTTPS host (for example Netlify, Cloudflare Pages, or GitHub Pages).

## Install
iPhone: open the hosted site in Safari → Share → Add to Home Screen.
Android: open in Chrome → menu → Install app / Add to Home screen.

Note: the password is a client-side convenience lock, not strong security. Anyone with access to the source code can inspect it.
